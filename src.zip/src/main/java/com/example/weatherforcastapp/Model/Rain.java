package com.example.weatherforcastapp.Model;

public class Rain {

}
